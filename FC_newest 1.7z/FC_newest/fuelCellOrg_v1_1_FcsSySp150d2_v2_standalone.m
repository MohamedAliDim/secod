%%
% 21/03/2023 - J.Herrmann - created v1_1 init file based on fuelCellOrg_v1_0_FcsSySp150d2_v3.m
% 24/03/2023 - J.Herrmann - updated/added parameters: rise-/fall-limits based on stack power, heat dissipation source selectable from map or fuel/efficiency, heat dissipation map
% 21/06/2023 - J.Herrmann - updated/added parameters to status HDT_FCPM_PerformanceData_v2.1.xlsm
% 17/07/2023 - J.Herrmann - added thermal parameters to be used also in fuelCellCtrl and fcpsCtrl by cross referencing
% we need to load the battery and motor parameters
% will use it on the simulation not on the scripts



% fuelCellOrg = FuelCellOrg_v1_1('fuelCellOrg');

fuelCellOrg.fileTitle             = 'FuelCellOrg';
fuelCellOrg.fileCreateDate        = '03/02/2022';
fuelCellOrg.fileUpdateDate        = '03/02/2022';
fuelCellOrg.fileAuthor            = 'M.MICHEL';
fuelCellOrg.fileComment           = 'default parameters';
fuelCellOrg.fileOrigin            = '';
fuelCellOrg.fileName              = mfilename;
fuelCellOrg.fileComment           = {'System SP150-v02, Date: 20.02.2023'};


%% Set aging; options: BOL, EOL, BOL_eTC, EOL_eTC (mainstream ..._eTC)
FCS_Age='BOL';

%% Parameters
fuelCellOrg.param.n_FcsCellCntSer.name    = 'Number of fuel cells in serial configuration';
fuelCellOrg.param.n_FcsCellCntSer.v       = 800;
fuelCellOrg.param.n_FcsCellCntSer.v_unit  = 'wu';
fuelCellOrg.param.n_FcsCellCntSer.comment = 'Number of fuel cells in serial configuration';

fuelCellOrg.param.A_FcsCellAct.name    = 'Active fuel cell area';
fuelCellOrg.param.A_FcsCellAct.v       = 263;
fuelCellOrg.param.A_FcsCellAct.v_unit  = 'cm^2';
fuelCellOrg.param.A_FcsCellAct.comment = 'Active fuel cell area';

fuelCellOrg.param.t_StckVoltLag.name    = 'time constant for FCS stack voltage lag';
fuelCellOrg.param.t_StckVoltLag.v       = 0.5;
fuelCellOrg.param.t_StckVoltLag.v_unit  = 's';
fuelCellOrg.param.t_StckVoltLag.comment = 'time constant for FCS stack voltage lag';

fuelCellOrg.param.t_StckCurrLag.name    = 'time constant for FCS stack current lag';
fuelCellOrg.param.t_StckCurrLag.v       = 0.5;
fuelCellOrg.param.t_StckCurrLag.v_unit  = 's';
fuelCellOrg.param.t_StckCurrLag.comment = 'time constant for FCS stack current lag';

fuelCellOrg.param.t_FcsAncLag.name    = 'time constant for FCS aux lag';
fuelCellOrg.param.t_FcsAncLag.v       = 0.1;
fuelCellOrg.param.t_FcsAncLag.v_unit  = 's';
fuelCellOrg.param.t_FcsAncLag.comment = 'time constant for FCS aux lag';

fuelCellOrg.param.t_StartupTime.name    = 'FCS startup time';
fuelCellOrg.param.t_StartupTime.v       = 30;
fuelCellOrg.param.t_StartupTime.v_unit  = '';
fuelCellOrg.param.t_StartupTime.comment = 'FCS startup time';

fuelCellOrg.param.t_ShutdownTime.name    = 'FCS shutdown time';
fuelCellOrg.param.t_ShutdownTime.v       = 180;
fuelCellOrg.param.t_ShutdownTime.v_unit  = '';
fuelCellOrg.param.t_ShutdownTime.comment = 'FCS shutdown time';

fuelCellOrg.param.t_dwell.name    = 'dwell time for FCS power request';
fuelCellOrg.param.t_dwell.v       = 3;
fuelCellOrg.param.t_dwell.v_unit  = '';
fuelCellOrg.param.t_dwell.comment = 'dwell time for FCS power request';

fuelCellOrg.param.P_FcsNetMinAllw.name    = 'FCS min. power';
fuelCellOrg.param.P_FcsNetMinAllw.v       = 14.8; % SY continuous assumption, transient ignored.
fuelCellOrg.param.P_FcsNetMinAllw.v_unit  = 'kW';
fuelCellOrg.param.P_FcsNetMinAllw.comment = 'FCS min. power';

fuelCellOrg.param.P_FcsStartupPwr.name    = 'FCS to FCPS PowerReq at Startup';
fuelCellOrg.param.P_FcsStartupPwr.v       = 0.25+0.5; % RF: tbc
fuelCellOrg.param.P_FcsStartupPwr.v_unit  = 'kW';
fuelCellOrg.param.P_FcsStartupPwr.comment = 'FCS to FCPS PowerReq at Startup';

fuelCellOrg.param.P_FcsShutdownPwr.name    = 'FCS to FCPS PowerReq at Shutdown';
fuelCellOrg.param.P_FcsShutdownPwr.v       = 0.25+1.0; % RF: tbc
fuelCellOrg.param.P_FcsShutdownPwr.v_unit  = 'kW';
fuelCellOrg.param.P_FcsShutdownPwr.comment = 'FCS to FCPS PowerReq at Shutdown';

fuelCellOrg.param.P_FcsRunPwr.name         = 'FCS to FCPS PowerReq in state Run';
fuelCellOrg.param.P_FcsRunPwr.v            = 0;  %0.3847; % from HD-CC_xEV_REPB_FCEV_Electrical_load_5_cycle_Version_2 - difference "engine on" - "engine off"
fuelCellOrg.param.P_FcsRunPwr.v_unit       = 'kW';
fuelCellOrg.param.P_FcsRunPwr.comment      = 'FCS to FCPS PowerReq in state Run';

fuelCellOrg.param.eta_DcDcBoost.name    = 'FCS DCDC efficiency';
fuelCellOrg.param.eta_DcDcBoost.v       = 0.97;
fuelCellOrg.param.eta_DcDcBoost.v_unit  = 'wu';
fuelCellOrg.param.eta_DcDcBoost.comment = 'FCS DCDC efficiency';

fuelCellOrg.param.H2MassFlowConsFactor.name    = 'factor for calculation of H2 mass flow';
fuelCellOrg.param.H2MassFlowConsFactor.v       = 96485.3399 * 2 / 2.016;
fuelCellOrg.param.H2MassFlowConsFactor.v_unit  = 'tbd';
fuelCellOrg.param.H2MassFlowConsFactor.comment = 'factor for calculation of H2 mass flow';

fuelCellOrg.param.StackDissHeatFactor.name    = 'factor for calculation of stack dissipated heat';
fuelCellOrg.param.StackDissHeatFactor.v       = 119940;
fuelCellOrg.param.StackDissHeatFactor.v_unit  = 'tbd';
fuelCellOrg.param.StackDissHeatFactor.comment = 'factor for calculation of stack dissipated heat';

fuelCellOrg.param.StackDissHeatSrcSel.name    = 'select heat dissipation calculated from fuel/efficiency (0) or 1D-map(1)';
fuelCellOrg.param.StackDissHeatSrcSel.v       = 1;
fuelCellOrg.param.StackDissHeatSrcSel.v_unit  = 'wu';
fuelCellOrg.param.StackDissHeatSrcSel.comment = 'select heat dissipation calculated from fuel/efficiency (0) or 1D-map(1)';

fuelCellOrg.param.e_KeyOn.name    = 'FCS activation flag';
fuelCellOrg.param.e_KeyOn.x       = [0 10000];
fuelCellOrg.param.e_KeyOn.x_unit  = 's';
fuelCellOrg.param.e_KeyOn.v       = [1 1];
fuelCellOrg.param.e_KeyOn.v_unit  = 'wu';
fuelCellOrg.param.e_KeyOn.comment = 'FCS activation flag';

fuelCellOrg.param.pump_ht_fuelcell.voltage_choice.name='select HTCP running on HV voltage level (1) or on 12V/LV level (0) - for power calculation based on current';
fuelCellOrg.param.pump_ht_fuelcell.voltage_choice.v = 1;
fuelCellOrg.param.pump_ht_fuelcell.voltage_choice.v_unit='-';

% Parameters from PTFc parameter list table BOL
Stack_Power_kW          =	[	0	13.77	16.49	19.48	31.12	45.96	60.60	74.50	87.90	100.80	114.00	126.45	139.50	151.80	162.72	174.72	185.50	195.00	];
FCS_HV_consumer_kW      =	[	0	0.85	0.90	1.11	1.63	2.20	3.67	5.89	8.21	9.92	12.03	14.99	18.26	22.91	24.15	25.06	29.20	34.55	];
Coolant_Pump_Power_kW	=	[	0	0.051	0.051	0.051	0.079	0.271	0.655	1.352	1.861	1.763	1.785	1.742	1.455	1.552	1.616	1.572	1.614	1.539	];
H2_feed_g_s             =	[	0	0.17	0.21	0.26	0.42	0.63	0.84	1.06	1.27	1.48	1.69	1.90	2.11	2.32	2.53	2.74	2.95	3.17	];
HR_to_HT_Coolant_kW     =	[	0	6.53	8.55	10.84	19.00	29.22	39.64	50.80	62.33	74.16	85.65	97.87	109.41	121.60	134.99	147.99	161.90	177.02	];
Air_flow_in_g_s         =	[	0	21.43	22.87	25.95	36.75	45.04	65.78	85.80	102.96	115.11	125.84	141.57	157.30	173.03	171.60	167.31	180.18	193.05	];
spec_cell_power_W_cm	=	[	0	0.065	0.078	0.093	0.148	0.218	0.288	0.354	0.418	0.479	0.542	0.601	0.663	0.721	0.773	0.830	0.882	0.927	];
Ucell_V                 =	[	0.850	0.850	0.825	0.805	0.778	0.766	0.758	0.745	0.733	0.720	0.713	0.703	0.698	0.690	0.678	0.672	0.663	0.650	];
dP_StackRiseLim_kW_s	=	[	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	];
dP_StackFallLim_kW_s	=	[	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	];
coolant_delta_T_K       =	[	3.00	3.00	3.00	3.00	3.00	3.00	3.00	3.00	3.30	4.00	4.60	5.30	6.30	6.85	7.50	8.30	9.00	10.00	];
coolant_out_temp_degC	=	[	70	70	70	70	70	70	70	70	71.3	74	76.6	78.6	80.7	83	87.5	88.3	89	90	];
coolant_flow_l_min      =	[	92	92	92	92	108	166	225	289	322	316	318	315	296	303	307	304	307	302	];


% Parameters from PTFc parameter list table EOL
Stack_Power_kW_EOL          =	[	0	13.68	16.36	19.28	30.57	44.73	58.42	71.09	82.99	94.12	105.27	115.40	125.86	135.30	143.08	151.67	158.77	164.32	];
FCS_HV_consumer_kW_EOL      =	[	0	0.88	0.94	1.15	1.64	2.24	3.78	6.17	8.67	10.42	12.62	15.64	18.86	23.62	24.94	25.90	30.11	35.47	];
Coolant_Pump_Power_kW_EOL	=	[	0	0.086	0.086	0.086	0.086	0.305	0.766	1.635	2.326	2.271	2.374	2.385	2.054	2.255	2.408	2.404	2.527	2.461	];
H2_feed_g_s_EOL             =	[	0	0.17	0.21	0.26	0.42	0.63	0.84	1.06	1.27	1.48	1.69	1.90	2.11	2.32	2.53	2.74	2.95	3.17	];
HR_to_HT_Coolant_kW_EOL     =	[	0	6.62	8.69	11.04	19.55	30.45	41.82	54.21	67.23	80.84	94.37	108.91	123.05	138.10	154.62	171.03	188.63	207.71	];
Air_flow_in_g_s_EOL         =	[	0	21.43	22.87	25.95	36.75	45.04	65.78	85.80	102.96	115.11	125.84	141.57	157.30	173.03	171.60	167.31	180.18	193.05	];
spec_cell_power_W_cm_EOL	=	[	0	0.065	0.078	0.092	0.145	0.213	0.278	0.338	0.394	0.447	0.500	0.549	0.598	0.643	0.680	0.721	0.755	0.781	];
Ucell_V_EOL                 =	[	0.850	0.844	0.818	0.797	0.764	0.746	0.730	0.711	0.692	0.672	0.658	0.641	0.629	0.615	0.596	0.583	0.567	0.548	];
dP_StackRiseLim_kW_s_EOL	=	[	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	];
dP_StackFallLim_kW_s_EOL	=	[	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	];
coolant_delta_T_K_EOL       =	[	3.00	3.00	3.00	3.00	3.00	3.00	3.00	3.00	3.30	4.00	4.60	5.30	6.30	6.85	7.50	8.30	9.00	10.00	];
coolant_out_temp_degC_EOL	=	[	70	70	70	70	70	70	70	70	71.3	74	76.6	78.6	80.7	83	87.5	88.3	89	90	];
coolant_flow_l_min_EOL      =	[	111	111	111	111	111	173	238	308	348	345	350	351	333	344	352	352	358	354	];

% Parameters from PTFc parameter list table BOL_eTC
Stack_Power_kW_BOL_eTC          =	[	0	13.77	16.49	19.48	31.12	45.96	60.60	74.50	87.90	100.80	114.00	126.45	139.50	151.80	162.72	174.72	185.50	195.00	];
FCS_HV_consumer_kW_BOL_eTC      =	[	0	0.76	0.81	1.00	1.51	2.06	3.49	5.65	7.83	9.28	10.98	13.52	16.25	20.07	20.69	20.98	24.24	28.64	];
Coolant_Pump_Power_kW_BOL_eTC	=	[	0	0.051	0.051	0.051	0.079	0.271	0.655	1.352	1.861	1.763	1.785	1.742	1.455	1.552	1.616	1.572	1.614	1.539	];
H2_feed_g_s_BOL_eTC             =	[	0	0.17	0.21	0.26	0.42	0.63	0.84	1.06	1.27	1.48	1.69	1.90	2.11	2.32	2.53	2.74	2.95	3.17	];
HR_to_HT_Coolant_kW_BOL_eTC     =	[	0	6.53	8.55	10.84	19.00	29.22	39.64	50.80	62.33	74.16	85.65	97.87	109.41	121.60	134.99	147.99	161.90	177.02	];
Air_flow_in_g_s_BOL_eTC         =	[	0	21.43	22.87	25.95	36.75	45.04	65.78	85.80	102.96	115.11	125.84	141.57	157.30	173.03	171.60	167.31	180.18	193.05	];
spec_cell_power_W_cm_BOL_eTC	=	[	0	0.065	0.078	0.093	0.148	0.218	0.288	0.354	0.418	0.479	0.542	0.601	0.663	0.721	0.773	0.830	0.882	0.927	];
Ucell_V_BOL_eTC                 =	[	0.850	0.850	0.825	0.805	0.778	0.766	0.758	0.745	0.733	0.720	0.713	0.703	0.698	0.690	0.678	0.672	0.663	0.650	];
dP_StackRiseLim_kW_s_BOL_eTC	=	[	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	];
dP_StackFallLim_kW_s_BOL_eTC	=	[	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	];
coolant_delta_T_K_BOL_eTC       =	[	3.00	3.00	3.00	3.00	3.00	3.00	3.00	3.00	3.30	4.00	4.60	5.30	6.30	6.85	7.50	8.30	9.00	10.00	];
coolant_out_temp_degC_BOL_eTC	=	[	70	70	70	70	70	70	70	70	71.3	74	76.6	78.6	80.7	83	87.5	88.3	89	90	];
coolant_flow_l_min_BOL_eTC      =	[	92	92	92	92	108	166	225	289	322	316	318	315	296	303	307	304	307	302	];

% Parameters from PTFc parameter list table EOL_eTC
Stack_Power_kW_EOL_eTC          =	[	0	13.68	16.35	19.28	30.57	44.73	58.42	71.09	82.99	94.12	105.27	115.40	125.86	135.30	143.08	151.67	158.77	164.32	];
FCS_HV_consumer_kW_EOL_eTC      =	[	0	0.79	0.85	1.03	1.52	2.10	3.60	5.93	8.29	9.78	11.57	14.17	16.85	20.78	21.48	21.82	25.16	29.56	];
Coolant_Pump_Power_kW_EOL_eTC	=	[	0	0.086	0.086	0.086	0.086	0.305	0.766	1.635	2.326	2.271	2.374	2.385	2.054	2.255	2.408	2.404	2.527	2.461	];
H2_feed_g_s_EOL_eTC             =	[	0	0.17	0.21	0.26	0.42	0.63	0.84	1.06	1.27	1.48	1.69	1.90	2.11	2.32	2.53	2.74	2.95	3.17	];
HR_to_HT_Coolant_kW_EOL_eTC     =	[	0	6.62	8.69	11.04	19.55	30.45	41.82	54.21	67.23	80.84	94.37	108.91	123.05	138.10	154.62	171.03	188.63	207.71	];
Air_flow_in_g_s_EOL_eTC         =	[	0	21.43	22.87	25.95	36.75	45.04	65.78	85.80	102.96	115.11	125.84	141.57	157.30	173.03	171.60	167.31	180.18	193.05	];
spec_cell_power_W_cm_EOL_eTC	=	[	0	0.065	0.078	0.092	0.145	0.213	0.278	0.338	0.394	0.447	0.500	0.549	0.598	0.643	0.680	0.721	0.755	0.781	];
Ucell_V_EOL_eTC                 =	[	0.850	0.844	0.818	0.797	0.764	0.746	0.730	0.711	0.692	0.672	0.658	0.641	0.629	0.615	0.596	0.583	0.567	0.548	];
dP_StackRiseLim_kW_s_EOL_eTC	=	[	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	5	];
dP_StackFallLim_kW_s_EOL_eTC	=	[	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	-300	];
coolant_delta_T_K_EOL_eTC       =	[	3.00	3.00	3.00	3.00	3.00	3.00	3.00	3.00	3.30	4.00	4.60	5.30	6.30	6.85	7.50	8.30	9.00	10.00	];
coolant_out_temp_degC_EOL_eTC	=	[	70	70	70	70	70	70	70	70	71.3	74	76.6	78.6	80.7	83	87.5	88.3	89	90	];
coolant_flow_l_min_EOL_eTC      =	[	111	111	111	111	111	173	238	308	348	345	350	351	333	344	352	352	358	354	];





switch FCS_Age
    case 'BOL'
        fuelCellOrg.param.FcsNetRiseLim.name    = 'FCS power max. rate limit'; %
        fuelCellOrg.param.FcsNetRiseLim.x       = Stack_Power_kW;
        fuelCellOrg.param.FcsNetRiseLim.x_unit  = 'kW';
        fuelCellOrg.param.FcsNetRiseLim.v       = dP_StackRiseLim_kW_s;
        fuelCellOrg.param.FcsNetRiseLim.v_unit  = 'kW*s^-1';
        fuelCellOrg.param.FcsNetRiseLim.comment = 'FCS power max. rate limit, x: FCS power, v: rate limit';
        
        fuelCellOrg.param.FcsNetFallLim.name    = 'FCS power min. rate limit'; %
        fuelCellOrg.param.FcsNetFallLim.x       = Stack_Power_kW;
        fuelCellOrg.param.FcsNetFallLim.x_unit  = 'kW';
        fuelCellOrg.param.FcsNetFallLim.v       = dP_StackFallLim_kW_s;
        fuelCellOrg.param.FcsNetFallLim.v_unit  = 'kW*s^-1';
        fuelCellOrg.param.FcsNetFallLim.comment = 'FCS power min. rate limit, x: FCS power, v: rate limit';

        fuelCellOrg.param.Fcs_Anc_Tbl.name    = 'FCS aux loss';
        fuelCellOrg.param.Fcs_Anc_Tbl.x       = Stack_Power_kW;
        fuelCellOrg.param.Fcs_Anc_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_Anc_Tbl.v       = FCS_HV_consumer_kW;
        fuelCellOrg.param.Fcs_Anc_Tbl.v_unit  = 'kW';
        fuelCellOrg.param.Fcs_Anc_Tbl.comment = 'FCS aux loss, x: FCS power, v: FCS aux loss';

        fuelCellOrg.param.P_FcsPumpHT.name    = 'FCS HT pump power';
        fuelCellOrg.param.P_FcsPumpHT.x       =  Stack_Power_kW * 1000; % use Watt as unit!
        fuelCellOrg.param.P_FcsPumpHT.x_unit  = 'W';
        fuelCellOrg.param.P_FcsPumpHT.v       =  Coolant_Pump_Power_kW * 1000; % use Watt as unit!
        fuelCellOrg.param.P_FcsPumpHT.v_unit  = 'W';
        fuelCellOrg.param.P_FcsPumpHT.comment = 'FCS HT pump power';

        fuelCellOrg.param.StackPolarization.name    = 'FCS Stack Polarization';
        fuelCellOrg.param.StackPolarization.x       =  Stack_Power_kW;
        fuelCellOrg.param.StackPolarization.x_unit  = 'kW';
        fuelCellOrg.param.StackPolarization.v       =  Ucell_V * fuelCellOrg.param.n_FcsCellCntSer.v;
        fuelCellOrg.param.StackPolarization.v_unit  = 'V';
        fuelCellOrg.param.StackPolarization.comment = 'FCS Stack Polarization, x: Gross Power, v: Stack Voltage';

        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.name    = 'FCS H2 consumption data';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.x       = Stack_Power_kW;
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.v       = H2_feed_g_s * 0.001;
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.v_unit  = 'kg*s^-1';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.comment = 'FCS H2 consumption data, x: FCS gross power, v: FCS H2 consupmtion rate';
        
        fuelCellOrg.param.Fcs_DissHeat_Tbl.name    = 'FCS dissipated heat as a function of stack power';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.x       = Stack_Power_kW;
        fuelCellOrg.param.Fcs_DissHeat_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.v       = HR_to_HT_Coolant_kW;
        fuelCellOrg.param.Fcs_DissHeat_Tbl.v_unit  = 'kW';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.comment = 'FCS dissipated heat, x: FCS power, v: FCS diss heat loss';
        
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.name    = 'air massflow through WCAC as a function of FCS gross power';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.x       = Stack_Power_kW;
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.v       = Air_flow_in_g_s * 0.001;
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.v_unit  = 'kg*s^-1';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.comment = 'air massflow through WCAC data, x: FCS gross power, v: air massflow through WCAC';
        
        fuelCellOrg.param.coolant_delta_T.name    = 'max stack coolant in/out delta T as a function of FCS gross power';
        fuelCellOrg.param.coolant_delta_T.x       = Stack_Power_kW;
        fuelCellOrg.param.coolant_delta_T.x_unit  = 'kW';
        fuelCellOrg.param.coolant_delta_T.v       = coolant_delta_T_K;
        fuelCellOrg.param.coolant_delta_T.v_unit  = 'K';
        fuelCellOrg.param.coolant_delta_T.comment = 'max stack coolant in/out delta T, x: FCS gross power, v: coolant in/out delta T';
        
        fuelCellOrg.param.coolant_out_temp_limit.name    = 'stack coolant out temparature target/limit as a function of FCS gross power';
        fuelCellOrg.param.coolant_out_temp_limit.x       = Stack_Power_kW;
        fuelCellOrg.param.coolant_out_temp_limit.x_unit  = 'kW';
        fuelCellOrg.param.coolant_out_temp_limit.v       = coolant_out_temp_degC + 273.15;
        fuelCellOrg.param.coolant_out_temp_limit.v_unit  = 'K';
        fuelCellOrg.param.coolant_out_temp_limit.comment = 'stack coolant out temparature target/limit, x: FCS gross power, v: coolant out temparature target/limit';
        
        fuelCellOrg.param.coolant_flow_target.name    = 'min coolant flow/coolant flow target as a function of FCS gross power';
        fuelCellOrg.param.coolant_flow_target.x       = Stack_Power_kW;
        fuelCellOrg.param.coolant_flow_target.x_unit  = 'kW';
        fuelCellOrg.param.coolant_flow_target.v       = coolant_flow_l_min / 60 / 1000;
        fuelCellOrg.param.coolant_flow_target.v_unit  = 'm^3*s^-1';
        fuelCellOrg.param.coolant_flow_target.comment = 'min coolant flow/coolant flow target, x: FCS gross power, v: coolant flow';
        
        fuelCellOrg.param.P_FcsNetMaxLim.name    = 'max. power provided by FCS';
        fuelCellOrg.param.P_FcsNetMaxLim.v       = 155.88;
        fuelCellOrg.param.P_FcsNetMaxLim.BOL.v   = fuelCellOrg.param.P_FcsNetMaxLim.v ; %used to define max power request in SOC based strategy
        fuelCellOrg.param.P_FcsNetMaxLim.v_unit  = 'kW';
        fuelCellOrg.param.P_FcsNetMaxLim.comment = 'max. power provided by FCS';
    
    case 'EOL'
        fuelCellOrg.param.FcsNetRiseLim.name    = 'FCS power max. rate limit'; %
        fuelCellOrg.param.FcsNetRiseLim.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.FcsNetRiseLim.x_unit  = 'kW';
        fuelCellOrg.param.FcsNetRiseLim.v       = dP_StackRiseLim_kW_s_EOL;
        fuelCellOrg.param.FcsNetRiseLim.v_unit  = 'kW*s^-1';
        fuelCellOrg.param.FcsNetRiseLim.comment = 'FCS power max. rate limit, x: FCS power, v: rate limit';
        
        fuelCellOrg.param.FcsNetFallLim.name    = 'FCS power min. rate limit'; %
        fuelCellOrg.param.FcsNetFallLim.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.FcsNetFallLim.x_unit  = 'kW';
        fuelCellOrg.param.FcsNetFallLim.v       = dP_StackFallLim_kW_s_EOL;
        fuelCellOrg.param.FcsNetFallLim.v_unit  = 'kW*s^-1';
        fuelCellOrg.param.FcsNetFallLim.comment = 'FCS power min. rate limit, x: FCS power, v: rate limit';

        fuelCellOrg.param.Fcs_Anc_Tbl.name    = 'FCS aux loss';
        fuelCellOrg.param.Fcs_Anc_Tbl.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.Fcs_Anc_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_Anc_Tbl.v       = FCS_HV_consumer_kW_EOL;
        fuelCellOrg.param.Fcs_Anc_Tbl.v_unit  = 'kW';
        fuelCellOrg.param.Fcs_Anc_Tbl.comment = 'FCS aux loss, x: FCS power, v: FCS aux loss';

        fuelCellOrg.param.P_FcsPumpHT.name    = 'FCS HT pump power';
        fuelCellOrg.param.P_FcsPumpHT.x       =  Stack_Power_kW_EOL * 1000; % use Watt as unit!
        fuelCellOrg.param.P_FcsPumpHT.x_unit  = 'W';
        fuelCellOrg.param.P_FcsPumpHT.v       =  Coolant_Pump_Power_kW_EOL * 1000; % use Watt as unit!
        fuelCellOrg.param.P_FcsPumpHT.v_unit  = 'W';
        fuelCellOrg.param.P_FcsPumpHT.comment = 'FCS HT pump power';

        fuelCellOrg.param.StackPolarization.name    = 'FCS Stack Polarization';
        fuelCellOrg.param.StackPolarization.x       =  Stack_Power_kW_EOL;
        fuelCellOrg.param.StackPolarization.x_unit  = 'kW';
        fuelCellOrg.param.StackPolarization.v       =  Ucell_V_EOL * fuelCellOrg.param.n_FcsCellCntSer.v;
        fuelCellOrg.param.StackPolarization.v_unit  = 'V';
        fuelCellOrg.param.StackPolarization.comment = 'FCS Stack Polarization, x: Gross Power, v: Stack Voltage';

        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.name    = 'FCS H2 consumption data';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.v       = H2_feed_g_s_EOL * 0.001;
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.v_unit  = 'kg*s^-1';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.comment = 'FCS H2 consumption data, x: FCS gross power, v: FCS H2 consupmtion rate';
        
        fuelCellOrg.param.Fcs_DissHeat_Tbl.name    = 'FCS dissipated heat as a function of stack power';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.Fcs_DissHeat_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.v       = HR_to_HT_Coolant_kW_EOL;
        fuelCellOrg.param.Fcs_DissHeat_Tbl.v_unit  = 'kW';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.comment = 'FCS dissipated heat, x: FCS power, v: FCS diss heat loss';
        
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.name    = 'air massflow through WCAC as a function of FCS gross power';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.v       = Air_flow_in_g_s_EOL * 0.001;
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.v_unit  = 'kg*s^-1';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.comment = 'air massflow through WCAC data, x: FCS gross power, v: air massflow through WCAC';

        fuelCellOrg.param.coolant_delta_T.name    = 'max stack coolant in/out delta T as a function of FCS gross power';
        fuelCellOrg.param.coolant_delta_T.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.coolant_delta_T.x_unit  = 'kW';
        fuelCellOrg.param.coolant_delta_T.v       = coolant_delta_T_K_EOL;
        fuelCellOrg.param.coolant_delta_T.v_unit  = 'K';
        fuelCellOrg.param.coolant_delta_T.comment = 'max stack coolant in/out delta T, x: FCS gross power, v: coolant in/out delta T';
        
        fuelCellOrg.param.coolant_out_temp_limit.name    = 'stack coolant out temparature target/limit as a function of FCS gross power';
        fuelCellOrg.param.coolant_out_temp_limit.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.coolant_out_temp_limit.x_unit  = 'kW';
        fuelCellOrg.param.coolant_out_temp_limit.v       = coolant_out_temp_degC_EOL + 273.15;
        fuelCellOrg.param.coolant_out_temp_limit.v_unit  = 'K';
        fuelCellOrg.param.coolant_out_temp_limit.comment = 'stack coolant out temparature target/limit, x: FCS gross power, v: coolant out temparature target/limit';
        
        fuelCellOrg.param.coolant_flow_target.name    = 'min coolant flow/coolant flow target as a function of FCS gross power';
        fuelCellOrg.param.coolant_flow_target.x       = Stack_Power_kW_EOL;
        fuelCellOrg.param.coolant_flow_target.x_unit  = 'kW';
        fuelCellOrg.param.coolant_flow_target.v       = coolant_flow_l_min_EOL / 60 / 1000;
        fuelCellOrg.param.coolant_flow_target.v_unit  = 'm^3*s^-1';
        fuelCellOrg.param.coolant_flow_target.comment = 'min coolant flow/coolant flow target, x: FCS gross power, v: coolant flow';
        
        fuelCellOrg.param.P_FcsNetMaxLim.name    = 'max. power provided by FCS';
        fuelCellOrg.param.P_FcsNetMaxLim.v       = 126.1;
        fuelCellOrg.param.P_FcsNetMaxLim.BOL.v   = 155.88; %used to define max power request in SOC based strategy
        fuelCellOrg.param.P_FcsNetMaxLim.v_unit  = 'kW';
        fuelCellOrg.param.P_FcsNetMaxLim.comment = 'max. power provided by FCS';

    case 'BOL_eTC'
        fuelCellOrg.param.FcsNetRiseLim.name    = 'FCS power max. rate limit'; %
        fuelCellOrg.param.FcsNetRiseLim.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.FcsNetRiseLim.x_unit  = 'kW';
        fuelCellOrg.param.FcsNetRiseLim.v       = dP_StackRiseLim_kW_s_BOL_eTC;
        fuelCellOrg.param.FcsNetRiseLim.v_unit  = 'kW*s^-1';
        fuelCellOrg.param.FcsNetRiseLim.comment = 'FCS power max. rate limit, x: FCS power, v: rate limit';
        
        fuelCellOrg.param.FcsNetFallLim.name    = 'FCS power min. rate limit'; %
        fuelCellOrg.param.FcsNetFallLim.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.FcsNetFallLim.x_unit  = 'kW';
        fuelCellOrg.param.FcsNetFallLim.v       = dP_StackFallLim_kW_s_BOL_eTC;
        fuelCellOrg.param.FcsNetFallLim.v_unit  = 'kW*s^-1';
        fuelCellOrg.param.FcsNetFallLim.comment = 'FCS power min. rate limit, x: FCS power, v: rate limit';

        fuelCellOrg.param.Fcs_Anc_Tbl.name    = 'FCS aux loss';
        fuelCellOrg.param.Fcs_Anc_Tbl.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.Fcs_Anc_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_Anc_Tbl.v       = FCS_HV_consumer_kW_BOL_eTC;
        fuelCellOrg.param.Fcs_Anc_Tbl.v_unit  = 'kW';
        fuelCellOrg.param.Fcs_Anc_Tbl.comment = 'FCS aux loss, x: FCS power, v: FCS aux loss';

        fuelCellOrg.param.P_FcsPumpHT.name    = 'FCS HT pump power';
        fuelCellOrg.param.P_FcsPumpHT.x       =  Stack_Power_kW_BOL_eTC * 1000; % use Watt as unit!
        fuelCellOrg.param.P_FcsPumpHT.x_unit  = 'W';
        fuelCellOrg.param.P_FcsPumpHT.v       =  Coolant_Pump_Power_kW_BOL_eTC * 1000; % use Watt as unit!
        fuelCellOrg.param.P_FcsPumpHT.v_unit  = 'W';
        fuelCellOrg.param.P_FcsPumpHT.comment = 'FCS HT pump power';

        fuelCellOrg.param.StackPolarization.name    = 'FCS Stack Polarization';
        fuelCellOrg.param.StackPolarization.x       =  Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.StackPolarization.x_unit  = 'kW';
        fuelCellOrg.param.StackPolarization.v       =  Ucell_V_BOL_eTC * fuelCellOrg.param.n_FcsCellCntSer.v;
        fuelCellOrg.param.StackPolarization.v_unit  = 'V';
        fuelCellOrg.param.StackPolarization.comment = 'FCS Stack Polarization, x: Gross Power, v: Stack Voltage';

        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.name    = 'FCS H2 consumption data';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.v       = H2_feed_g_s_BOL_eTC * 0.001;
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.v_unit  = 'kg*s^-1';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.comment = 'FCS H2 consumption data, x: FCS gross power, v: FCS H2 consupmtion rate';
        
        fuelCellOrg.param.Fcs_DissHeat_Tbl.name    = 'FCS dissipated heat as a function of stack power';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.Fcs_DissHeat_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.v       = HR_to_HT_Coolant_kW_BOL_eTC;
        fuelCellOrg.param.Fcs_DissHeat_Tbl.v_unit  = 'kW';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.comment = 'FCS dissipated heat, x: FCS power, v: FCS diss heat loss';
        
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.name    = 'air massflow through WCAC as a function of FCS gross power';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.v       = Air_flow_in_g_s_BOL_eTC * 0.001;
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.v_unit  = 'kg*s^-1';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.comment = 'air massflow through WCAC data, x: FCS gross power, v: air massflow through WCAC';
        
        fuelCellOrg.param.coolant_delta_T.name    = 'max stack coolant in/out delta T as a function of FCS gross power';
        fuelCellOrg.param.coolant_delta_T.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.coolant_delta_T.x_unit  = 'kW';
        fuelCellOrg.param.coolant_delta_T.v       = coolant_delta_T_K_BOL_eTC;
        fuelCellOrg.param.coolant_delta_T.v_unit  = 'K';
        fuelCellOrg.param.coolant_delta_T.comment = 'max stack coolant in/out delta T, x: FCS gross power, v: coolant in/out delta T';
        
        fuelCellOrg.param.coolant_out_temp_limit.name    = 'stack coolant out temparature target/limit as a function of FCS gross power';
        fuelCellOrg.param.coolant_out_temp_limit.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.coolant_out_temp_limit.x_unit  = 'kW';
        fuelCellOrg.param.coolant_out_temp_limit.v       = coolant_out_temp_degC_BOL_eTC + 273.15;
        fuelCellOrg.param.coolant_out_temp_limit.v_unit  = 'K';
        fuelCellOrg.param.coolant_out_temp_limit.comment = 'stack coolant out temparature target/limit, x: FCS gross power, v: coolant out temparature target/limit';
        
        fuelCellOrg.param.coolant_flow_target.name    = 'min coolant flow/coolant flow target as a function of FCS gross power';
        fuelCellOrg.param.coolant_flow_target.x       = Stack_Power_kW_BOL_eTC;
        fuelCellOrg.param.coolant_flow_target.x_unit  = 'kW';
        fuelCellOrg.param.coolant_flow_target.v       = coolant_flow_l_min_BOL_eTC / 60 / 1000;
        fuelCellOrg.param.coolant_flow_target.v_unit  = 'm^3*s^-1';
        fuelCellOrg.param.coolant_flow_target.comment = 'min coolant flow/coolant flow target, x: FCS gross power, v: coolant flow';
        
        fuelCellOrg.param.P_FcsNetMaxLim.name    = 'max. power provided by FCS';
        fuelCellOrg.param.P_FcsNetMaxLim.v       = 161.79;
        fuelCellOrg.param.P_FcsNetMaxLim.BOL.v   = fuelCellOrg.param.P_FcsNetMaxLim.v ; %used to define max power request in SOC based strategy
        fuelCellOrg.param.P_FcsNetMaxLim.v_unit  = 'kW';
        fuelCellOrg.param.P_FcsNetMaxLim.comment = 'max. power provided by FCS';
        
    
    case 'EOL_eTC'
        fuelCellOrg.param.FcsNetRiseLim.name    = 'FCS power max. rate limit'; %
        fuelCellOrg.param.FcsNetRiseLim.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.FcsNetRiseLim.x_unit  = 'kW';
        fuelCellOrg.param.FcsNetRiseLim.v       = dP_StackRiseLim_kW_s_EOL_eTC;
        fuelCellOrg.param.FcsNetRiseLim.v_unit  = 'kW*s^-1';
        fuelCellOrg.param.FcsNetRiseLim.comment = 'FCS power max. rate limit, x: FCS power, v: rate limit';
        
        fuelCellOrg.param.FcsNetFallLim.name    = 'FCS power min. rate limit'; %
        fuelCellOrg.param.FcsNetFallLim.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.FcsNetFallLim.x_unit  = 'kW';
        fuelCellOrg.param.FcsNetFallLim.v       = dP_StackFallLim_kW_s_EOL_eTC;
        fuelCellOrg.param.FcsNetFallLim.v_unit  = 'kW*s^-1';
        fuelCellOrg.param.FcsNetFallLim.comment = 'FCS power min. rate limit, x: FCS power, v: rate limit';

        fuelCellOrg.param.Fcs_Anc_Tbl.name    = 'FCS aux loss';
        fuelCellOrg.param.Fcs_Anc_Tbl.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.Fcs_Anc_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_Anc_Tbl.v       = FCS_HV_consumer_kW_EOL_eTC;
        fuelCellOrg.param.Fcs_Anc_Tbl.v_unit  = 'kW';
        fuelCellOrg.param.Fcs_Anc_Tbl.comment = 'FCS aux loss, x: FCS power, v: FCS aux loss';

        fuelCellOrg.param.P_FcsPumpHT.name    = 'FCS HT pump power';
        fuelCellOrg.param.P_FcsPumpHT.x       =  Stack_Power_kW_EOL_eTC * 1000; % use Watt as unit!
        fuelCellOrg.param.P_FcsPumpHT.x_unit  = 'W';
        fuelCellOrg.param.P_FcsPumpHT.v       =  Coolant_Pump_Power_kW_EOL_eTC * 1000; % use Watt as unit!
        fuelCellOrg.param.P_FcsPumpHT.v_unit  = 'W';
        fuelCellOrg.param.P_FcsPumpHT.comment = 'FCS HT pump power';

        fuelCellOrg.param.StackPolarization.name    = 'FCS Stack Polarization';
        fuelCellOrg.param.StackPolarization.x       =  Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.StackPolarization.x_unit  = 'kW';
        fuelCellOrg.param.StackPolarization.v       =  Ucell_V_EOL * fuelCellOrg.param.n_FcsCellCntSer.v;
        fuelCellOrg.param.StackPolarization.v_unit  = 'V';
        fuelCellOrg.param.StackPolarization.comment = 'FCS Stack Polarization, x: Gross Power, v: Stack Voltage';

        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.name    = 'FCS H2 consumption data';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.v       = H2_feed_g_s_EOL_eTC * 0.001;
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.v_unit  = 'kg*s^-1';
        fuelCellOrg.param.Fcs_HydrogenFeed_Tbl.comment = 'FCS H2 consumption data, x: FCS gross power, v: FCS H2 consupmtion rate';
        
        fuelCellOrg.param.Fcs_DissHeat_Tbl.name    = 'FCS dissipated heat as a function of stack power';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.Fcs_DissHeat_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.v       = HR_to_HT_Coolant_kW_EOL_eTC;
        fuelCellOrg.param.Fcs_DissHeat_Tbl.v_unit  = 'kW';
        fuelCellOrg.param.Fcs_DissHeat_Tbl.comment = 'FCS dissipated heat, x: FCS power, v: FCS diss heat loss';
        
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.name    = 'air massflow through WCAC as a function of FCS gross power';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.x_unit  = 'kW';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.v       = Air_flow_in_g_s_EOL_eTC * 0.001;
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.v_unit  = 'kg*s^-1';
        fuelCellOrg.param.Fcs_mflow_air_WCAC_Tbl.comment = 'air massflow through WCAC data, x: FCS gross power, v: air massflow through WCAC';

        fuelCellOrg.param.coolant_delta_T.name    = 'max stack coolant in/out delta T as a function of FCS gross power';
        fuelCellOrg.param.coolant_delta_T.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.coolant_delta_T.x_unit  = 'kW';
        fuelCellOrg.param.coolant_delta_T.v       = coolant_delta_T_K_EOL_eTC;
        fuelCellOrg.param.coolant_delta_T.v_unit  = 'K';
        fuelCellOrg.param.coolant_delta_T.comment = 'max stack coolant in/out delta T, x: FCS gross power, v: coolant in/out delta T';
        
        fuelCellOrg.param.coolant_out_temp_limit.name    = 'stack coolant out temparature target/limit as a function of FCS gross power';
        fuelCellOrg.param.coolant_out_temp_limit.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.coolant_out_temp_limit.x_unit  = 'kW';
        fuelCellOrg.param.coolant_out_temp_limit.v       = coolant_out_temp_degC_EOL_eTC + 273.15;
        fuelCellOrg.param.coolant_out_temp_limit.v_unit  = 'K';
        fuelCellOrg.param.coolant_out_temp_limit.comment = 'stack coolant out temparature target/limit, x: FCS gross power, v: coolant out temparature target/limit';
        
        fuelCellOrg.param.coolant_flow_target.name    = 'min coolant flow/coolant flow target as a function of FCS gross power';
        fuelCellOrg.param.coolant_flow_target.x       = Stack_Power_kW_EOL_eTC;
        fuelCellOrg.param.coolant_flow_target.x_unit  = 'kW';
        fuelCellOrg.param.coolant_flow_target.v       = coolant_flow_l_min_EOL_eTC / 60 / 1000;
        fuelCellOrg.param.coolant_flow_target.v_unit  = 'm^3*s^-1';
        fuelCellOrg.param.coolant_flow_target.comment = 'min coolant flow/coolant flow target, x: FCS gross power, v: coolant flow';
        
        fuelCellOrg.param.P_FcsNetMaxLim.name    = 'max. power provided by FCS';
        fuelCellOrg.param.P_FcsNetMaxLim.v       = 132.03;
        fuelCellOrg.param.P_FcsNetMaxLim.BOL.v   = 161.79; %used to define max power request in SOC based strategy
        fuelCellOrg.param.P_FcsNetMaxLim.v_unit  = 'kW';
        fuelCellOrg.param.P_FcsNetMaxLim.comment = 'max. power provided by FCS';        
        
end

%% create generic DCDC map with constant efficiency characteristic
Map4d_DCDC_BoostFCS_ConstEff;

% delete temporary parameters
clearvars Stack_Power_kW FCS_HV_consumer_kW Coolant_Pump_Power_kW H2_feed_g_s HR_to_HT_Coolant_kW Air_flow_in_g_s spec_cell_power_W_cm Ucell_V dP_StackRiseLim_kW_s dP_StackFallLim_kW_s Stack_Power_kW_EOL FCS_HV_consumer_kW_EOL Coolant_Pump_Power_kW_EOL H2_feed_g_s_EOL HR_to_HT_Coolant_kW_EOL Air_flow_in_g_s_EOL spec_cell_power_W_cm_EOL Ucell_V_EOL dP_StackRiseLim_kW_s_EOL dP_StackFallLim_kW_s_EOL Stack_Power_kW_BOL_eTC FCS_HV_consumer_kW_BOL_eTC Coolant_Pump_Power_kW_BOL_eTC H2_feed_g_s_BOL_eTC HR_to_HT_Coolant_kW_BOL_eTC Air_flow_in_g_s_BOL_eTC spec_cell_power_W_cm_BOL_eTC Ucell_V_BOL_eTC dP_StackRiseLim_kW_s_BOL_eTC dP_StackFallLim_kW_s_BOL_eTC Stack_Power_kW_EOL_eTC FCS_HV_consumer_kW_EOL_eTC Coolant_Pump_Power_kW_EOL_eTC H2_feed_g_s_EOL_eTC HR_to_HT_Coolant_kW_EOL_eTC Air_flow_in_g_s_EOL_eTC spec_cell_power_W_cm_EOL_eTC Ucell_V_EOL_eTC dP_StackRiseLim_kW_s_EOL_eTC dP_StackFallLim_kW_s_EOL_eTC