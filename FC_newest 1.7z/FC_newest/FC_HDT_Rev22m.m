clear;
clc
cd('D:\StratOpt_HDT_FC\FC_HDT_rev2')
load('Battery_Data.mat')
load('City_cycle_Data.mat')
aging={'BOL', 'EOL', 'BOL_eTC', 'EOL_eTC'};
modelname='FC_HDT_Model.slx';uiopen(modelname,1);
% CombinedEDMElectricalPower from excel sheet
Pwrdes=CombinedEDMElectricalPower;
stpsz=0.0125;
twdw=max(Time);
simendt=max(Time);
Temp=25;%[48, 0, -30];%DegC
FCS_Age=aging{2};
Reserve=reshape(Reserve,[],1);
SlctdStrategy=1;
WDD=343;
DCThdFCOn=30;
v=1;
for i=10%:numel(Reserve)
    SD=Reserve(1);
    WD=window(i);
    %Preq=PowerReq(:,i);   
    FCSimPdes=Pwrdes;
    FCSimPdesTime=Time;
    DC =100;
    run('fuelCellOrg_v1_1_FcsSySp150d2_v2_standalone.m');
    run('Map4d_DCDC_BoostFCS_ConstEff.m');
    PwrReqTime = Time;% Time from excel sheet starting [ 0 to 2746]
    FCPSTemp       = [Temp      Temp]+273;
    simstrtt=0;
    SOC_overrideValue             = [20   20        20 ];            
    SOC_overrideEnable            = [1     0         0 ];
    SOCInitTime                   = [0  0.02       twdw];
    Energy_overrideEnable         = [1     0         0 ];
    Battery_Energy_overrideEnable = [1     0         0 ];
    Energy_Time           = [0  0.02     twdw  ];
    % run the simulink model 
    sim(modelname);
    FCSResMaxPreq(i,v)    =max(Preq);
    FCSResefficiency(i,v) =distance_miles(end)/(MassH2_kg(end)*3.377);
    tempvar=getsampleusingtime(SOC,stpsz);tempvar=tempvar.Data;
    FCSResSOCStrt(i,v)=tempvar(end);
    SOCstar               = tempvar(end);
    tempvar=getsampleusingtime(SOC,simendt);tempvar=tempvar.Data;
    FCSResSOCEnd(i,v)     =tempvar(end);
    SOCend                = tempvar(end);
    FCSResDeltaSOC(i,v)   =SOCstar- SOCend;
    %**********************************************************************
   % tempvar=getsampleusingtime(Battery_energy,stpsz);tempvar=tempvar.Data;
   %FCSResEnergyStrt(i,v)=tempvar(end);
   % Energystart                = tempvar(end);
    %tempvar=getsampleusingtime(Battery_energy,simendt);tempvar=tempvar.Data;
    %FCSResEnergyEnd(i,v)     =tempvar(end);
   % Energyend                 = tempvar(end);
    %FCSResDeltaEnergy(i,v)   =Energystart- Energyend;v=v+1;
    
end
tableData = zeros(length(Reserve), length(window));
rowNames = cell(length(b), 1);
colNames = cell(length(window), 1);
for j = 1:length(window)
    colNames{j} = num2str(window(j));
end
for k = 1:length(Reserve)
    rowNames{k} = num2str(b(k));
end


%dataTable = array2table(FCSResefficiency, 'RowNames', rowNames, 'VariableNames', colNames);
%dataTableMaxPreq = array2table(FCSResMaxPreq, 'RowNames', rowNames, 'VariableNames', colNames);
%dataTableDeltaSOC = array2table(FCSResDeltaSOC, 'RowNames', rowNames, 'VariableNames', colNames);
%dataTableDeltaEnergy = array2table(FCSResDeltaEnergy, 'RowNames', rowNames, 'VariableNames', colNames);



