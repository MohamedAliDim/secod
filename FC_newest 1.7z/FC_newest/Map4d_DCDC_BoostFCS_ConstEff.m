%%
% v1 - 2022/xx/xx - MK: efficiency map calculated from power loss map
% v2 - 2022/07/13 - MK: added column: losses for 0 W LV Power, changed from eff. to abs. loss in model
% v3 - 2023/01/25 - RF: generic model w/ const. efficiency characteristic. Requires input characteristic from fuelCellOrg file.

%%

% if not(structfieldexist('fuelCellOrg.param.eta_DcDcBoost','v'))
%     fuelCellOrg.param.eta_DcDcBoost.v       = 0.98;
% end

Map4d.Temp      = [-40 100] + 273.15;
Map4d.VoltageLV = [0 1000];
Map4d.VoltageHV = [0 1000];
Map4d.PowerLV   = [0 1000] * 1000;

% stand-by power consumption
Map4d.PowerLV;

[dummy_Map4d.Temp dummy_Map4d.VoltageLV dummy_Map4d.VoltageHV dummy_Map4d.PowerLV] = ndgrid(Map4d.Temp,Map4d.VoltageLV,Map4d.VoltageHV,Map4d.PowerLV);

Map4d.v = (1-fuelCellOrg.param.eta_DcDcBoost.v).*dummy_Map4d.PowerLV;

fuelCellOrg.param.eta_DcDcBoostMap4d = Map4d;
clear dummy_Map4d